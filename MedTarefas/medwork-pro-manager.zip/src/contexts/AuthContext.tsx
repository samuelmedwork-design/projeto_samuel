import { createContext, useContext, useState, ReactNode } from "react";
import { User, mockUsers, Sector } from "@/lib/mock-data";

interface AuthContextType {
  user: User | null;
  allUsers: User[];
  login: (email: string, password: string) => boolean;
  logout: () => void;
  canAccessSector: (sector: Sector) => boolean;
  updateProfile: (data: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be inside AuthProvider");
  return ctx;
};

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [registeredUsers] = useState<User[]>(mockUsers);
  const [user, setUser] = useState<User | null>(null);

  const login = (email: string, password: string) => {
    const found = registeredUsers.find((u) => u.email === email && u.password === password);
    if (found) {
      setUser(found);
      return true;
    }
    return false;
  };

  const logout = () => setUser(null);

  const canAccessSector = (sector: Sector) => {
    if (!user) return false;
    if (user.is_admin) return true;
    return user.sectors.includes(sector);
  };

  const updateProfile = (data: Partial<User>) => {
    setUser((prev) => prev ? { ...prev, ...data } : prev);
  };

  return (
    <AuthContext.Provider value={{ user, allUsers: registeredUsers, login, logout, canAccessSector, updateProfile }}>
      {children}
    </AuthContext.Provider>
  );
};
