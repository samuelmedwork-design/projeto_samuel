import { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { LayoutDashboard, User, LogOut, List, ChevronDown, ChevronRight, Stethoscope, Briefcase, Heart, DollarSign, Crown, Lock, PanelLeftClose, PanelLeft, Menu, Calendar } from "lucide-react";
import { cn } from "@/lib/utils";
import { SECTORS, Sector } from "@/lib/mock-data";
import medworkLogo from "@/assets/medwork-logo.png";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

const sectorIcons: Record<Sector, React.ElementType> = {
  tecnico: Stethoscope,
  comercial: Briefcase,
  saude: Heart,
  financeiro: DollarSign,
  diretoria: Crown,
};

const STORAGE_KEY = "medwork-sidebar-collapsed";

export const AppSidebar = () => {
  const { user, logout, canAccessSector } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [expandedSectors, setExpandedSectors] = useState<Sector[]>([]);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(() => {
    try { return localStorage.getItem(STORAGE_KEY) === "true"; } catch { return false; }
  });

  useEffect(() => { setMobileOpen(false); }, [location.pathname]);

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, String(collapsed)); } catch {}
    document.body.classList.toggle("sidebar-collapsed", collapsed);
    return () => { document.body.classList.remove("sidebar-collapsed"); };
  }, [collapsed]);

  const toggleSector = (sector: Sector) => {
    setExpandedSectors((prev) =>
      prev.includes(sector) ? prev.filter((s) => s !== sector) : [...prev, sector]
    );
  };

  const topLinks = [
    { to: "/dashboard/projects", label: "Dashboard", icon: LayoutDashboard },
    { to: "/profile", label: "Perfil", icon: User },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <>
      {/* Mobile hamburger */}
      <button
        onClick={() => setMobileOpen(true)}
        className="md:hidden fixed top-3 left-3 z-50 p-2.5 rounded-[12px] bg-card border border-border shadow-card text-foreground"
      >
        <Menu className="w-5 h-5" />
      </button>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="md:hidden fixed inset-0 z-40 bg-foreground/10 backdrop-blur-sm transition-all" onClick={() => setMobileOpen(false)} />
      )}

      <aside className={cn(
        "h-screen bg-card border-r border-border flex flex-col fixed left-0 top-0 z-50 transition-all duration-200",
        collapsed ? "w-16" : "w-60",
        "max-md:w-60",
        mobileOpen ? "max-md:translate-x-0" : "max-md:-translate-x-full"
      )}>
        {/* Logo */}
        <div className={cn("px-4 py-4 flex items-center border-b border-border", collapsed ? "flex-col gap-2 px-2" : "justify-between")}>
          <Link to="/dashboard/projects" className={cn("flex items-center gap-2.5", collapsed && "justify-center")}>
            <div className={cn("rounded-[10px] overflow-hidden", collapsed ? "w-8 h-8" : "w-10 h-10")}>
              <img src={medworkLogo} alt="MedWork" className="w-full h-full object-contain" />
            </div>
            {!collapsed && (
              <div>
                <span className="font-semibold text-foreground text-[13px]">MedWork</span>
                <span className="block text-[10px] text-muted-foreground leading-none">Medicina e Segurança</span>
              </div>
            )}
          </Link>
          <button
            onClick={() => setCollapsed(prev => !prev)}
            className="p-1.5 rounded-lg hover:bg-muted transition-all duration-200 text-muted-foreground hover:text-foreground"
          >
            {collapsed ? <PanelLeft className="w-4 h-4" /> : <PanelLeftClose className="w-4 h-4" />}
          </button>
        </div>

        {/* Top nav */}
        <nav className="px-3 pt-3 space-y-1">
          {topLinks.map(({ to, label, icon: Icon }) => (
            <Tooltip key={to}>
              <TooltipTrigger asChild>
                <Link
                  to={to}
                  className={cn(
                    "flex items-center gap-2.5 px-3 py-2 rounded-[10px] text-[13px] transition-all duration-200",
                    isActive(to)
                      ? "bg-accent text-accent-foreground font-medium"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted",
                    collapsed && "justify-center px-2"
                  )}
                >
                  <Icon className="w-[18px] h-[18px] flex-shrink-0 stroke-[1.5]" />
                  {!collapsed && <span>{label}</span>}
                </Link>
              </TooltipTrigger>
              {collapsed && <TooltipContent side="right"><p className="text-xs">{label}</p></TooltipContent>}
            </Tooltip>
          ))}
        </nav>

        {/* Divider */}
        <div className={cn("px-4 py-3", collapsed && "px-2")}>
          <div className="h-px bg-border" />
          {!collapsed && (
            <span className="block text-[10px] font-medium text-muted-foreground uppercase tracking-widest mt-3 mb-1 px-1">Setores</span>
          )}
        </div>

        {/* Sectors */}
        <nav className="flex-1 px-3 space-y-0.5 overflow-y-auto pb-4">
          {SECTORS.map(({ id, label }) => {
            const Icon = sectorIcons[id];
            const isExpanded = expandedSectors.includes(id);
            const sectorDashPath = `/dashboard/projects/${id}`;
            const sectorListPath = `/projetos/${id}`;
            const isSectorActive = location.pathname.includes(id);
            const hasAccess = canAccessSector(id);

            return (
              <div key={id}>
                {hasAccess ? (
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <button
                        onClick={() => {
                          if (collapsed) { navigate(sectorDashPath); }
                          else {
                            toggleSector(id);
                            if (!isExpanded) navigate(sectorDashPath);
                          }
                        }}
                        className={cn(
                          "flex items-center gap-2.5 px-3 py-2 rounded-[10px] text-[13px] transition-all duration-200 w-full text-left",
                          isSectorActive
                            ? "bg-accent text-accent-foreground font-medium"
                            : "text-muted-foreground hover:text-foreground hover:bg-muted",
                          collapsed && "justify-center px-2"
                        )}
                      >
                        <Icon className="w-[18px] h-[18px] flex-shrink-0 stroke-[1.5]" />
                        {!collapsed && (
                          <>
                            <span className="flex-1 truncate">{label}</span>
                            {isExpanded ? <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" /> : <ChevronRight className="w-3.5 h-3.5 text-muted-foreground" />}
                          </>
                        )}
                      </button>
                    </TooltipTrigger>
                    {collapsed && <TooltipContent side="right"><p className="text-xs">{label}</p></TooltipContent>}
                  </Tooltip>
                ) : (
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div className={cn(
                        "flex items-center gap-2.5 px-3 py-2 rounded-[10px] text-[13px] text-muted-foreground/40 cursor-not-allowed w-full",
                        collapsed && "justify-center px-2"
                      )}>
                        <Icon className="w-[18px] h-[18px] flex-shrink-0 stroke-[1.5]" />
                        {!collapsed && (
                          <>
                            <span className="flex-1 truncate">{label}</span>
                            <Lock className="w-3 h-3" />
                          </>
                        )}
                      </div>
                    </TooltipTrigger>
                    <TooltipContent side="right"><p className="text-xs">Sem acesso</p></TooltipContent>
                  </Tooltip>
                )}

                {isExpanded && hasAccess && !collapsed && (
                  <div className="ml-5 mt-0.5 space-y-0.5 border-l-2 border-border pl-3 animate-fade-in">
                    <Link
                      to={sectorDashPath}
                      className={cn(
                        "flex items-center gap-2 px-2.5 py-1.5 rounded-[8px] text-xs transition-all duration-200",
                        isActive(sectorDashPath)
                          ? "bg-accent text-accent-foreground font-medium"
                          : "text-muted-foreground hover:text-foreground hover:bg-muted"
                      )}
                    >
                      <LayoutDashboard className="w-3.5 h-3.5 stroke-[1.5]" />
                      Quadro
                    </Link>
                    <Link
                      to={sectorListPath}
                      className={cn(
                        "flex items-center gap-2 px-2.5 py-1.5 rounded-[8px] text-xs transition-all duration-200",
                        isActive(sectorListPath)
                          ? "bg-accent text-accent-foreground font-medium"
                          : "text-muted-foreground hover:text-foreground hover:bg-muted"
                      )}
                    >
                      <List className="w-3.5 h-3.5 stroke-[1.5]" />
                      Projetos
                    </Link>
                    {id === "tecnico" && (
                      <Link
                        to="/calendario/tecnico"
                        className={cn(
                          "flex items-center gap-2 px-2.5 py-1.5 rounded-[8px] text-xs transition-all duration-200",
                          isActive("/calendario/tecnico")
                            ? "bg-accent text-accent-foreground font-medium"
                            : "text-muted-foreground hover:text-foreground hover:bg-muted"
                        )}
                      >
                        <Calendar className="w-3.5 h-3.5 stroke-[1.5]" />
                        Calendário
                      </Link>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </nav>

        {/* User footer */}
        <div className="p-3 border-t border-border">
          <div className={cn("flex items-center gap-2.5 mb-2", collapsed && "justify-center")}>
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-[11px] font-medium text-primary-foreground flex-shrink-0">
              {user?.full_name?.split(" ").map((n) => n[0]).join("").slice(0, 2)}
            </div>
            {!collapsed && (
              <div className="flex-1 min-w-0">
                <div className="text-[13px] font-medium text-foreground truncate">{user?.full_name}</div>
                <div className="text-[11px] text-muted-foreground truncate">
                  {user?.is_admin ? "Admin" : user?.sectors.map(s => SECTORS.find(sec => sec.id === s)?.label).filter(Boolean).join(", ")}
                </div>
              </div>
            )}
          </div>
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={logout}
                className={cn(
                  "flex items-center gap-2 text-[13px] text-muted-foreground hover:text-destructive transition-all duration-200 w-full px-3 py-1.5 rounded-[8px] hover:bg-muted",
                  collapsed && "justify-center px-2"
                )}
              >
                <LogOut className="w-4 h-4 flex-shrink-0 stroke-[1.5]" />
                {!collapsed && "Sair"}
              </button>
            </TooltipTrigger>
            {collapsed && <TooltipContent side="right"><p className="text-xs">Sair</p></TooltipContent>}
          </Tooltip>
        </div>
      </aside>
    </>
  );
};
