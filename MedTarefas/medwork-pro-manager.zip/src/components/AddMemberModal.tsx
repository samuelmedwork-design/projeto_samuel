import { useState } from "react";
import { useProjects } from "@/contexts/ProjectContext";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { UserPlus } from "lucide-react";
import { Sector, SECTORS, User } from "@/lib/mock-data";

interface AddMemberModalProps {
  editingUser?: User | null;
  onClose?: () => void;
}

export const AddMemberModal = ({ editingUser, onClose }: AddMemberModalProps) => {
  const { addUser, updateUser } = useProjects();
  const [open, setOpen] = useState(false);
  const isEditing = !!editingUser;
  const isControlled = editingUser !== undefined;

  const [form, setForm] = useState({
    full_name: editingUser?.full_name || "",
    cpf: editingUser?.cpf || "",
    email: editingUser?.email || "",
    password: editingUser?.password || "",
    sectors: editingUser?.sectors || [] as Sector[],
  });

  const toggleSector = (sector: Sector) => {
    setForm((p) => ({
      ...p,
      sectors: p.sectors.includes(sector)
        ? p.sectors.filter((s) => s !== sector)
        : [...p.sectors, sector],
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (form.sectors.length === 0) return;

    if (isEditing && editingUser) {
      updateUser(editingUser.id, { ...form });
    } else {
      addUser({ ...form, is_admin: false, company_id: "1" });
    }
    setForm({ full_name: "", cpf: "", email: "", password: "", sectors: [] });
    if (onClose) onClose();
    setOpen(false);
  };

  const handleOpenChange = (v: boolean) => {
    if (!v && onClose) onClose();
    setOpen(v);
  };

  const dialogOpen = isControlled ? !!editingUser : open;

  return (
    <Dialog open={dialogOpen} onOpenChange={handleOpenChange}>
      {!isControlled && (
        <DialogTrigger asChild>
          <Button className="gap-2 btn-3d gradient-primary text-primary-foreground rounded-xl font-semibold shadow-elevated hover:shadow-3d-hover transition-all duration-300 hover:-translate-y-0.5">
            <UserPlus className="w-4 h-4" />
            Adicionar Responsável
          </Button>
        </DialogTrigger>
      )}
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Editar Responsável" : "Adicionar Responsável"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-2">
          <div className="space-y-2">
            <Label>Nome Completo</Label>
            <Input value={form.full_name} onChange={(e) => setForm((p) => ({ ...p, full_name: e.target.value }))} required />
          </div>
          <div className="space-y-2">
            <Label>CPF</Label>
            <Input value={form.cpf} onChange={(e) => setForm((p) => ({ ...p, cpf: e.target.value }))} placeholder="000.000.000-00" required />
          </div>
          <div className="space-y-2">
            <Label>Email Profissional</Label>
            <Input type="email" value={form.email} onChange={(e) => setForm((p) => ({ ...p, email: e.target.value }))} required />
          </div>
          <div className="space-y-2">
            <Label>Senha</Label>
            <Input type="password" value={form.password} onChange={(e) => setForm((p) => ({ ...p, password: e.target.value }))} placeholder="••••••••" required />
          </div>
          <div className="space-y-2">
            <Label>Setores *</Label>
            <div className="flex flex-wrap gap-2">
              {SECTORS.map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => toggleSector(s.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-all duration-200 ${
                    form.sectors.includes(s.id)
                      ? "gradient-primary text-primary-foreground border-primary shadow-sm"
                      : "bg-muted text-muted-foreground border-border hover:border-primary/50 hover:bg-accent"
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
            {form.sectors.length === 0 && (
              <p className="text-xs text-destructive">Selecione ao menos um setor</p>
            )}
          </div>
          <Button type="submit" className="w-full btn-3d gradient-primary text-primary-foreground rounded-xl font-semibold">
            {isEditing ? "Salvar Alterações" : "Salvar Responsável"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
};
