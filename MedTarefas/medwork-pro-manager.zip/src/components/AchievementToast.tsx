import { useState, useEffect } from "react";
import { Trophy } from "lucide-react";

interface AchievementToastProps {
  show: boolean;
  projectName: string;
  onClose: () => void;
}

export const AchievementToast = ({ show, projectName, onClose }: AchievementToastProps) => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (show) {
      setVisible(true);
      const timer = setTimeout(() => {
        setVisible(false);
        setTimeout(onClose, 300);
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [show, onClose]);

  if (!show && !visible) return null;

  return (
    <div className={`fixed top-6 right-6 z-[100] transition-all duration-500 ${visible ? "opacity-100 translate-y-0 scale-100" : "opacity-0 -translate-y-4 scale-95"}`}>
      <div className="bg-card border border-border rounded-2xl shadow-lg p-5 flex items-center gap-4 min-w-[320px]">
        <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center animate-bounce">
          <Trophy className="w-6 h-6 text-primary" />
        </div>
        <div className="flex-1">
          <p className="text-sm font-semibold text-foreground">🎉 Parabéns!</p>
          <p className="text-xs text-muted-foreground mt-0.5">
            Você concluiu <span className="font-medium text-foreground">"{projectName}"</span>
          </p>
          <p className="text-[11px] text-primary font-medium mt-1">+100 pontos • Continue assim!</p>
        </div>
      </div>
    </div>
  );
};
