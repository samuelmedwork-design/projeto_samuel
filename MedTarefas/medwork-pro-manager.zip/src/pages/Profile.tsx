import { useState } from "react";
import { useProjects } from "@/contexts/ProjectContext";
import { useAuth } from "@/contexts/AuthContext";
import { AppSidebar } from "@/components/AppSidebar";
import { AddMemberModal } from "@/components/AddMemberModal";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Trophy, Target, CheckCircle2, Clock, TrendingUp, Medal, AlertCircle, Pencil, Trash2, UserCog, Star, Award, Zap, Crown } from "lucide-react";
import { User, SECTORS } from "@/lib/mock-data";

const Profile = () => {
  const { projects, getPoints, getMedals, users, deleteUser, updateUser } = useProjects();
  const { user, updateProfile } = useAuth();
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [deletingUser, setDeletingUser] = useState<User | null>(null);
  const [editingSelf, setEditingSelf] = useState(false);
  const [selfForm, setSelfForm] = useState({ full_name: "", email: "", password: "" });

  const notAuth = projects.filter((p) => p.status === "not_authenticated").length;
  const notStarted = projects.filter((p) => p.status === "not_started").length;
  const pending = projects.filter((p) => p.status === "pending").length;
  const done = projects.filter((p) => p.status === "done").length;
  const points = getPoints();
  const medals = getMedals();

  const getLevel = () => {
    if (done >= 70) return { name: "Elite", icon: Crown, color: "text-primary", bg: "bg-primary/10", progress: 100 };
    if (done >= 31) return { name: "Alta Performance", icon: Zap, color: "text-amber-500", bg: "bg-amber-50", progress: Math.round(((done - 31) / 39) * 100) };
    if (done >= 11) return { name: "Produtivo", icon: Award, color: "text-blue-500", bg: "bg-blue-50", progress: Math.round(((done - 11) / 19) * 100) };
    return { name: "Iniciante", icon: Star, color: "text-muted-foreground", bg: "bg-muted", progress: Math.round((done / 10) * 100) };
  };

  const level = getLevel();
  const LevelIcon = level.icon;

  const getFeedback = () => {
    if (done > notStarted + pending) return { msg: "Excelente! Sua equipe está concluindo mais do que planejando. Continue assim! 🚀", type: "success" as const };
    if (pending > done) return { msg: "Muitos projetos pendentes. Considere focar em concluí-los antes de iniciar novos.", type: "warning" as const };
    return { msg: "Equilíbrio saudável entre planejamento e execução. Bom trabalho! 👏", type: "neutral" as const };
  };

  const feedback = getFeedback();

  const stats = [
    { label: "Não Autenticado", value: notAuth, icon: AlertCircle, color: "text-status-not-authenticated", bg: "bg-status-not-authenticated-bg" },
    { label: "Não Iniciado", value: notStarted, icon: Clock, color: "text-status-not-started", bg: "bg-status-not-started-bg" },
    { label: "Pendentes", value: pending, icon: TrendingUp, color: "text-status-pending", bg: "bg-status-pending-bg" },
    { label: "Concluídos", value: done, icon: CheckCircle2, color: "text-status-done", bg: "bg-status-done-bg" },
  ];

  const handleDelete = () => {
    if (deletingUser) {
      deleteUser(deletingUser.id);
      setDeletingUser(null);
    }
  };

  const openEditSelf = () => {
    if (!user) return;
    setSelfForm({ full_name: user.full_name, email: user.email, password: "" });
    setEditingSelf(true);
  };

  const handleSaveSelf = () => {
    if (!user) return;
    const updates: Partial<User> = {};
    if (selfForm.full_name && selfForm.full_name !== user.full_name) updates.full_name = selfForm.full_name;
    if (selfForm.email && selfForm.email !== user.email) updates.email = selfForm.email;
    if (selfForm.password) updates.password = selfForm.password;
    if (Object.keys(updates).length > 0) {
      updateProfile(updates);
      updateUser(user.id, updates);
    }
    setEditingSelf(false);
  };

  return (
    <div className="min-h-screen flex">
      <AppSidebar />
      <main className="flex-1 ml-60 sidebar-collapsed:ml-16 p-6 md:p-8 transition-all duration-200">
        <div className="max-w-4xl animate-fade-in">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-xl font-semibold text-foreground">Perfil & Desempenho</h1>
              <p className="text-muted-foreground text-sm mt-1">Métricas e gestão da equipe</p>
            </div>
            <AddMemberModal />
          </div>

          {/* User info */}
          <Card className="mb-6 border-border shadow-card rounded-[12px] overflow-hidden">
            <CardContent className="p-5 flex items-center gap-4">
              <div className="w-12 h-12 rounded-[12px] bg-primary flex items-center justify-center text-base font-medium text-primary-foreground">
                {user?.full_name?.split(" ").map((n) => n[0]).join("").slice(0, 2)}
              </div>
              <div className="flex-1">
                <h2 className="text-base font-semibold text-foreground">{user?.full_name}</h2>
                <p className="text-muted-foreground text-[13px]">{user?.email}</p>
                <span className="inline-block mt-1 px-2 py-0.5 text-[11px] font-medium rounded-full status-concluido">
                  {user?.is_admin ? "Administrador" : "Colaborador"}
                </span>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={openEditSelf}
                className="gap-2 rounded-[10px] text-[13px] hover:bg-muted transition-all duration-200 h-9"
              >
                <UserCog className="w-4 h-4" />
                Editar Perfil
              </Button>
            </CardContent>
          </Card>

          {/* Gamification */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <Card className="border-border shadow-card rounded-[12px]">
              <CardContent className="p-5 flex items-center gap-3">
                <div className="w-9 h-9 rounded-[10px] bg-accent flex items-center justify-center">
                  <Trophy className="w-4 h-4 text-accent-foreground stroke-[1.5]" />
                </div>
                <div>
                  <div className="text-xl font-semibold text-foreground">{points}</div>
                  <div className="text-[13px] text-muted-foreground">Pontos</div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-border shadow-card rounded-[12px]">
              <CardContent className="p-5 flex items-center gap-3">
                <div className="w-9 h-9 rounded-[10px] bg-accent flex items-center justify-center">
                  <Medal className="w-4 h-4 text-accent-foreground stroke-[1.5]" />
                </div>
                <div>
                  <div className="text-xl font-semibold text-foreground">{medals}</div>
                  <div className="text-[13px] text-muted-foreground">Medalhas</div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-border shadow-card rounded-[12px]">
              <CardContent className="p-5 flex items-center gap-3">
                <div className={`w-9 h-9 rounded-[10px] ${level.bg} flex items-center justify-center`}>
                  <LevelIcon className={`w-4 h-4 ${level.color} stroke-[1.5]`} />
                </div>
                <div>
                  <div className="text-sm font-semibold text-foreground">{level.name}</div>
                  <div className="text-[11px] text-muted-foreground">Nível</div>
                  <div className="w-16 h-1.5 bg-muted rounded-full mt-1 overflow-hidden">
                    <div className="h-full bg-primary rounded-full transition-all duration-500" style={{ width: `${level.progress}%` }} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-4 gap-3 mb-6">
            {stats.map(({ label, value, icon: Icon, color, bg }) => (
              <Card key={label} className="border-border shadow-card rounded-[12px] hover:shadow-card-hover transition-all duration-200">
                <CardContent className="p-4 text-center">
                  <div className={`w-8 h-8 rounded-[10px] ${bg} flex items-center justify-center mx-auto mb-2`}>
                    <Icon className={`w-4 h-4 ${color} stroke-[1.5]`} />
                  </div>
                  <div className="text-xl font-semibold text-foreground">{value}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">{label}</div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Feedback */}
          <Card className={`border-border shadow-card rounded-xl ${feedback.type === "success" ? "border-l-2 border-l-status-done" : feedback.type === "warning" ? "border-l-2 border-l-status-not-started" : ""}`}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Target className="w-4 h-4 text-primary" />
                Feedback Inteligente
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-sm text-muted-foreground">{feedback.msg}</p>
            </CardContent>
          </Card>

          <h3 className="text-base font-semibold text-foreground mt-8 mb-4">Equipe ({users.length})</h3>
          <div className="grid grid-cols-2 gap-3">
            {users.map((u) => (
              <Card key={u.id} className="border-border shadow-card rounded-xl hover:shadow-card-hover transition-all duration-150 group">
                <CardContent className="p-4 flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-xs font-medium text-primary-foreground">
                    {u.full_name.split(" ").map((n) => n[0]).join("").slice(0, 2)}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-medium text-foreground truncate">{u.full_name}</div>
                    <div className="text-xs text-muted-foreground truncate">{u.email}</div>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {u.sectors.map((s) => (
                        <span key={s} className="text-[10px] px-1.5 py-0.5 rounded bg-accent text-accent-foreground font-medium">
                          {SECTORS.find((sec) => sec.id === s)?.label || s}
                        </span>
                      ))}
                    </div>
                  </div>
                  {user?.is_admin && u.id !== user.id && (
                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-7 w-7 rounded-lg hover:bg-muted"
                        onClick={() => setEditingUser(u)}
                      >
                        <Pencil className="w-3.5 h-3.5 text-muted-foreground" />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-7 w-7 rounded-lg hover:bg-destructive/10"
                        onClick={() => setDeletingUser(u)}
                      >
                        <Trash2 className="w-3.5 h-3.5 text-destructive" />
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Edit Member Modal */}
          {editingUser && (
            <AddMemberModal editingUser={editingUser} onClose={() => setEditingUser(null)} />
          )}

          {/* Edit Self Dialog */}
          <Dialog open={editingSelf} onOpenChange={(v) => !v && setEditingSelf(false)}>
            <DialogContent className="sm:max-w-sm">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <UserCog className="w-5 h-5 text-primary" />
                  Editar Perfil
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Nome</Label>
                  <Input
                    value={selfForm.full_name}
                    onChange={(e) => setSelfForm({ ...selfForm, full_name: e.target.value })}
                    className="rounded-xl"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input
                    type="email"
                    value={selfForm.email}
                    onChange={(e) => setSelfForm({ ...selfForm, email: e.target.value })}
                    className="rounded-xl"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Nova Senha <span className="text-muted-foreground text-xs">(deixe em branco para manter)</span></Label>
                  <Input
                    type="password"
                    value={selfForm.password}
                    onChange={(e) => setSelfForm({ ...selfForm, password: e.target.value })}
                    placeholder="••••••••"
                    className="rounded-xl"
                  />
                </div>
                <div className="flex gap-3 pt-2">
                  <Button variant="outline" className="flex-1 rounded-lg" onClick={() => setEditingSelf(false)}>
                    Cancelar
                  </Button>
                  <Button onClick={handleSaveSelf} className="flex-1 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90">
                    Salvar
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          {/* Delete Confirmation Dialog */}
          <Dialog open={!!deletingUser} onOpenChange={(v) => !v && setDeletingUser(null)}>
            <DialogContent className="sm:max-w-sm">
              <DialogHeader>
                <DialogTitle>Excluir Responsável</DialogTitle>
              </DialogHeader>
              <p className="text-sm text-muted-foreground">
                Tem certeza que deseja excluir <strong>{deletingUser?.full_name}</strong>? Esta ação não pode ser desfeita.
              </p>
              <div className="flex gap-3 mt-4">
                <Button variant="outline" className="flex-1 rounded-xl" onClick={() => setDeletingUser(null)}>
                  Cancelar
                </Button>
                <Button variant="destructive" className="flex-1 rounded-xl btn-3d" onClick={handleDelete}>
                  Excluir
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </main>
    </div>
  );
};

export default Profile;
