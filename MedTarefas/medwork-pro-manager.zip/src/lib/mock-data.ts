export type Sector = "tecnico" | "comercial" | "saude" | "financeiro" | "diretoria";

export const SECTORS: { id: Sector; label: string }[] = [
  { id: "tecnico", label: "Setor Técnico" },
  { id: "comercial", label: "Comercial" },
  { id: "saude", label: "Saúde" },
  { id: "financeiro", label: "Financeiro" },
  { id: "diretoria", label: "Diretoria" },
];

export interface User {
  id: string;
  full_name: string;
  cpf: string;
  email: string;
  password: string;
  is_admin: boolean;
  company_id: string;
  sectors: Sector[];
}

export type TecnicoResponsavel = "Caio" | "Anielson" | "Pedro" | "Aline" | "Samuel" | "Fernando" | "Zona de Espera";
export type TecnicoPrioridade = "Baixa" | "Média" | "Alta" | "Crítica";
export type TecnicoStatus = "Não cadastradas no ESO" | "Não iniciadas" | "Visita pendente" | "Documentação pendente" | "Revisão" | "Finalizada";

export const TECNICO_RESPONSAVEIS: TecnicoResponsavel[] = ["Caio", "Anielson", "Pedro", "Aline", "Samuel", "Fernando", "Zona de Espera"];
export const TECNICO_PRIORIDADES: TecnicoPrioridade[] = ["Baixa", "Média", "Alta", "Crítica"];
export const TECNICO_STATUS_OPTIONS: TecnicoStatus[] = ["Não cadastradas no ESO", "Não iniciadas", "Visita pendente", "Documentação pendente", "Revisão", "Finalizada"];

export interface ProjectAttachment {
  id: string;
  name: string;
  size: number;
  type: string;
  url: string;
  uploadedAt: string;
  uploadedBy: string;
}

export interface TecnicoProject {
  id: string;
  empresa: string;
  cnpj: string;
  responsavel: TecnicoResponsavel;
  regiao: string;
  prioridade: TecnicoPrioridade;
  data: string;
  status_tecnico: TecnicoStatus;
  contato_nome: string;
  contato_telefone: string;
  contato_email: string;
  dados_extras: string;
  sector: "tecnico";
  attachments?: ProjectAttachment[];
}

export interface Project {
  id: string;
  company_id: string;
  project_name: string;
  description?: string;
  cnpj?: string;
  start_date?: string;
  due_date: string;
  status: "not_authenticated" | "not_started" | "pending" | "doc_pending" | "review" | "done";
  sector: Sector;
  is_renovation?: boolean;
  responsible_ids: string[];
  created_at: string;
  attachments?: ProjectAttachment[];
}

export interface ProjectMessage {
  id: string;
  projeto_id: string;
  usuario_id: string;
  conteudo: string;
  criado_em: string;
  attachments?: ProjectAttachment[];
}

// Kanban Variáveis - independent cards not linked to projects
export interface KanbanVariavelCard {
  id: string;
  title: string;
  description: string;
  status: Project["status"];
  prioridade: TecnicoPrioridade;
  createdAt: string;
  empresa?: string;
  cnpj?: string;
  responsavel?: string;
  regiao?: string;
  data?: string;
  status_tecnico?: string;
  contato_nome?: string;
  contato_telefone?: string;
  contato_email?: string;
  dados_extras?: string;
  attachments?: ProjectAttachment[];
}

export const mockUsers: User[] = [
  { id: "1", full_name: "Ana Silva", cpf: "123.456.789-00", email: "ana@medwork.com", password: "admin123", is_admin: true, company_id: "1", sectors: ["diretoria", "tecnico", "comercial", "saude", "financeiro"] },
  { id: "2", full_name: "Carlos Mendes", cpf: "987.654.321-00", email: "carlos@medwork.com", password: "123456", is_admin: false, company_id: "1", sectors: ["tecnico"] },
  { id: "3", full_name: "Beatriz Costa", cpf: "456.789.123-00", email: "beatriz@medwork.com", password: "123456", is_admin: false, company_id: "1", sectors: ["saude"] },
  { id: "4", full_name: "Diego Ferreira", cpf: "321.654.987-00", email: "diego@medwork.com", password: "123456", is_admin: false, company_id: "1", sectors: ["comercial"] },
];

export const mockProjects: Project[] = [
  { id: "1", company_id: "1", project_name: "PPRA - Empresa ABC", description: "Programa de prevenção de riscos ambientais", due_date: "2026-04-15", status: "not_started", sector: "tecnico", responsible_ids: ["1", "2"], created_at: "2026-03-01", start_date: "2026-03-05" },
  { id: "2", company_id: "1", project_name: "ASO - Colaboradores XYZ", description: "Atestados de saúde ocupacional", due_date: "2026-05-01", status: "not_authenticated", sector: "saude", responsible_ids: ["3"], created_at: "2026-03-10" },
  { id: "3", company_id: "1", project_name: "Proposta Comercial - Ind. Beta", description: "Elaboração de proposta comercial", due_date: "2026-03-30", status: "pending", sector: "comercial", responsible_ids: ["2", "4"], created_at: "2026-02-20", start_date: "2026-02-25" },
  { id: "4", company_id: "1", project_name: "Relatório Fiscal Q1", description: "Relatório fiscal do primeiro trimestre", due_date: "2026-04-20", status: "not_authenticated", sector: "financeiro", responsible_ids: ["1"], created_at: "2026-03-15" },
  { id: "5", company_id: "1", project_name: "PCMSO - Empresa Delta", description: "Programa de controle médico", due_date: "2026-03-25", status: "done", sector: "tecnico", responsible_ids: ["4"], created_at: "2026-01-10", start_date: "2026-01-15" },
  { id: "6", company_id: "1", project_name: "Reunião Diretoria", description: "Planejamento estratégico anual", due_date: "2026-03-20", status: "done", sector: "diretoria", responsible_ids: ["2", "3"], created_at: "2026-02-01", start_date: "2026-02-05" },
  { id: "7", company_id: "1", project_name: "Renovação PPRA - Empresa Gama", description: "Renovação anual do programa", due_date: "2026-06-01", status: "pending", sector: "tecnico", is_renovation: true, responsible_ids: ["1"], created_at: "2026-03-20" },
];

export const mockMessages: ProjectMessage[] = [
  { id: "1", projeto_id: "1", usuario_id: "1", conteudo: "Iniciando o PPRA. Visita técnica agendada!", criado_em: "2026-03-05T10:00:00Z" },
  { id: "2", projeto_id: "1", usuario_id: "2", conteudo: "Ótimo! Vou preparar os instrumentos de medição.", criado_em: "2026-03-05T14:30:00Z" },
  { id: "3", projeto_id: "3", usuario_id: "4", conteudo: "Proposta em fase de elaboração. Previsão de entrega sexta.", criado_em: "2026-02-25T09:00:00Z" },
];

export const mockTecnicoProjects: TecnicoProject[] = [
  { id: "t1", empresa: "Empresa ABC", cnpj: "12.345.678/0001-90", responsavel: "Caio", regiao: "São Paulo - SP", prioridade: "Baixa", data: "15/04/2026", status_tecnico: "Não iniciadas", contato_nome: "João Silva", contato_telefone: "(11) 99999-0000", contato_email: "joao@abc.com", dados_extras: "", sector: "tecnico" },
  { id: "t2", empresa: "Indústria Beta", cnpj: "98.765.432/0001-10", responsavel: "Anielson", regiao: "Campinas - SP", prioridade: "Crítica", data: "20/03/2026", status_tecnico: "Visita pendente", contato_nome: "Maria Santos", contato_telefone: "(19) 98888-0000", contato_email: "maria@beta.com", dados_extras: "Urgente - fiscalização próxima", sector: "tecnico" },
  { id: "t3", empresa: "Construtora Delta", cnpj: "11.222.333/0001-44", responsavel: "Pedro", regiao: "Rio de Janeiro - RJ", prioridade: "Alta", data: "10/04/2026", status_tecnico: "Finalizada", contato_nome: "Carlos Lima", contato_telefone: "(21) 97777-0000", contato_email: "carlos@delta.com", dados_extras: "", sector: "tecnico" },
];

export const mockKanbanVariavelCards: KanbanVariavelCard[] = [
  { id: "kv1", title: "Verificar documentação pendente", description: "Checar docs da empresa X", status: "not_started", prioridade: "Média", createdAt: new Date().toISOString() },
  { id: "kv2", title: "Agendar visita técnica", description: "Empresa Y precisa de visita", status: "pending", prioridade: "Alta", createdAt: new Date().toISOString() },
];

// Legacy exports for backward compatibility
export type TecnicoVisita = string;
export type TecnicoMedicao = string;
export type TecnicoDocumento = string;
export const TECNICO_VISITAS: string[] = [];
export const TECNICO_MEDICOES: string[] = [];
export const TECNICO_DOCUMENTOS: string[] = [];
